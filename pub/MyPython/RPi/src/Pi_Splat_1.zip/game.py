class Game():
	def __init__(self):
		pass
