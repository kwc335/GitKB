import math,random,pygame,sys
from fruit import *; from game import *; from turret import *; from bullet import *

##TOP LEVEL CONSTANTS
FPS = 30
WINDOWWIDTH=480; WINDOWHEIGHT=640
GAMETITLE="Pi Splat"
WHITE=[255,255,255]; RED=[255,0,0]; GREEN=[0,255,0]; BLUE=[0,0,255]; BLACK=[0,0,0]

def main():
	#set up initial display
	pygame.init()
	clock=pygame.time.Clock()
	surface=pygame.display.set_mode([WINDOWWIDTH,WINDOWHEIGHT])
	pygame.display.set_caption(GAMETITLE)

	#MAIN GAME LOOP
	game_over=False
	
	while game_over==False:
		for event in pygame.event.get():
			if event.type==pygame.KEYDOWN:
				if event.key==pygame.K_ESCAPE:
					game_over=True
		print pygame.time.get_ticks() # used to prove the loop is working
		pygame.display.update()
		clock.tick(FPS)
	
if __name__ == '__main__':
    main()
