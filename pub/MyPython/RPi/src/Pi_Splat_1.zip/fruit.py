class Fruit():
	def __init__(self):
		pass
